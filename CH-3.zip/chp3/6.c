// Online C compiler to run C program onlin\

#include <stdio.h>

int main() {
    // Write C code here
    int a,b,c,d,sum;
    printf("enter the angles a,b,c");
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    sum=a+b+c;

    if (sum==180){
        printf("triangle");

    }
    
    else{
        printf("no trigangle");
    }

    
}