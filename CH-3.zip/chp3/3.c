// Online C compiler to run C program online
#include <stdio.h>

int main() {
    // Write C code here
    int c,s,p;
    printf("enter the interger");
    scanf("%d",&c);
    if (c%4==0){
        printf("leap year");
        
    }
    

    return 0;
}