// Online C compiler to run C program online
#include <stdio.h>

int main() {
    // Write C code here
    int a,b,c,d;
    printf("enter the interger");
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    if (a<b && a<c){
        printf("a is smallest");

    }
    elseif(b<a && b<c){
        printf("b is smallest");
    
        
    }
    else{
        printf("c is smallest");
    }

    
}