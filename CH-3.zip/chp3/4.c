// Online C compiler to run C program online
#include <stdio.h>

int main() {
    // Write C code here
    int c,s,p,t;
    printf("enter the interger");
    scanf("%d",&c);
    while(c>0){
        t=c%10;
        p=p*10+t;
        
        c=c/10;
        

        
    }
    printf("%d",p);

    return 0;
}