// Online C compiler to run C program online
#include <stdio.h>

int main() {
    // Write C code here
    int c,s,p;
    printf("enter the interger");
    scanf("%d",&c);
    if (c%2==0){
        printf("even");
        
    }
    else{
        printf("odd");
    }
    

    return 0;
}