// Online C compiler  run C program onlin\

#include <stdio.h>
#include <stdlib.h>

int main() {
    // Write C code here
    int a,b,c,d,sum;
    printf("enter the number");
    scanf("%d",&a);
    sum=abs(a);
   
    printf("abs value %d",sum);

    
}