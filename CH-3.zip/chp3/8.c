// Online C compiler  run C program onlin\

#include <stdio.h>
#include <stdlib.h>

int main() {
    // Write C code here
    int a,b,area,peri;
    printf("enter the lenght and breadth");
    scanf("%d\n",&a);
    scanf("%d\n",&b);
    area=a*b;
    peri=(2*(a+b));
    printf("%d\n",area);
    printf("%d\n",peri);
    if(area>peri){
        printf("area is greater");
        
    }
    else{
        printf("perimeter is greater");
        
    }
    
    

    
}