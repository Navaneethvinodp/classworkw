#include <stdio.h>

int main() {
    // Write C code here
    int c,s,p;
    printf("enter the cost price and selling ");
    scanf("%d",&c);
    scanf("%d",&s);
    p=s-c;
    if (p<c){
        printf("profit %d",p);
        
    }
    else{
        printf("loss=%d",p);
        
    }

    return 0;
}