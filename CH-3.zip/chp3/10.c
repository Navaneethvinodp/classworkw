#include <stdio.h>
#include <math.h>

int main() {
    float centerX, centerY, radius, pointX, pointY;

    printf("Enter the x-coordinate of the center of the circle: ");
    scanf("%f", &centerX);

    printf("Enter the y-coordinate of the center of the circle: ");
    scanf("%f", &centerY);

    printf("Enter the radius of the circle: ");
    scanf("%f", &radius);

    printf("Enter the x-coordinate of the point: ");
    scanf("%f", &pointX);

    printf("Enter the y-coordinate of the point: ");
    scanf("%f", &pointY);

    float distance = sqrt(pow((pointX - centerX), 2) + pow((pointY - centerY), 2));

    if (distance < radius) {
        printf("The point lies inside the circle.\n");
    } else if (distance == radius) {
        printf("The point lies on the circle.\n");
    } else {
        printf("The point lies outside the circle.\n");
    }

    return 0;
}
