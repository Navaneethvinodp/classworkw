#include <stdio.h>

int main() {
    char ch;

    printf("Enter a character: ");
    scanf("%c", &ch);

    (ch >= 'a' && ch <= 'z') ? printf("%c is a lowercase alphabet.\n", ch) : printf("%c is not a lowercase alphabet.\n", ch);

    ((ch >= 33 && ch <= 47) || (ch >= 58 && ch <= 64) || (ch >= 91 && ch <= 96) || (ch >= 123 && ch <= 126))
        ? printf("%c is a special symbol.\n", ch) : printf("%c is not a special symbol.\n", ch);

    return 0;
}
