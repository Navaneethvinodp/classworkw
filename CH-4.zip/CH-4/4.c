#include <stdio.h>

int main() {
    float a, b, c;

    printf("Enter the length of side 1: ");
    scanf("%f", &a);

    printf("Enter the length of side 2: ");
    scanf("%f", &b);

    printf("Enter the length of side 3: ");
    scanf("%f", &c);

    if ((a + b > b) && (a + c > b) && (b + c > a)) {
        printf("The triangle is valid.\n");
    } 
    else {
        printf("The triangle is not valid.\n");
    }

    return 0;
}
