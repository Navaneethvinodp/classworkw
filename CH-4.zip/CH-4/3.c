#include <stdio.h>

int main() {
    float hardness, cc, ts;

    printf("Enter the hardness of the steel: ");
    scanf("%f", &hardness);

    printf("Enter the carbon content of the steel: ");
    scanf("%f", &c);

    printf("Enter the tensile strength of the steel: ");
    scanf("%f", &ts);

    int grade;

    if (hardness > 50 && c < 0.7 && ts > 5600) {
        grade = 10;
    } 
    else if (hardness > 50 && cc < 0.7) {
        grade = 9;
    } 
    else if (cc < 0.7 && ts > 5600) {
        grade = 8;
    } 
    else if (hardness > 50 && ts > 5600) {
        grade = 7;
    } 
    else if (hardness > 50 || cc < 0.7 || ts > 5600) {
        grade = 6;
    } 
    else {
        grade = 5;
    }

    printf("The grade of the steel is: %d\n", grade);

    return 0;
}
