#include <stdio.h>
#include <math.h>

int main() {
    float angle;

    printf("Enter the angle in degrees: ");
    scanf("%f", &angle);

    float radians = angle * M_PI / 180.0;
    float sine = sin(radians);
    float cosine = cos(radians);
    float sum_of_squares = sine * sine + cosine * cosine;

    if (sum_of_squares == 1) {
        printf("The sum of squares of sine and cosine is equal to 1.\n");
    } else {
        printf("The sum of squares of sine and cosine is not equal to 1.\n");
    }

    return 0;
}
