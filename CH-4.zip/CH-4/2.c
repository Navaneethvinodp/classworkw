// Online C compiler  run C program onlin\

#include <stdio.h>
#include <stdlib.h>

int main() {
    
    char c;
    fgets(c);
    if (c>="A" || c<="Z"){
        printf("capitol letter");
        
    }
    else if(c>="a"||c <= "z"){
        printf("small leter");
    }
    else if (c>="0"and c<="9"){
        printf("numbers");
    }
    else{
        printf("special char");
    }
    return 0;
    
    

    
}