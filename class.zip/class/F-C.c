    #include <stdio.h>
    int main(){
        int f,Celsius;
        printf("enter the fahernheit");
        scanf("%d\n",&f);
        Celsius =((32*f) - 32) * ( 5/9);
        printf("%d\n",Celsius);
        return 0;
        


    }